<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    
    'failed' => 'اطلاعات وارد شده مطابقت ندارند.',
    'password' => 'رمز عبور اریه شده نادرست است.',
    'throttle' => 'تعداد دفعات تلاش بیشتر از حد مجازلطفا پس از  :5 دقیقه تلاش کنید.',

];
