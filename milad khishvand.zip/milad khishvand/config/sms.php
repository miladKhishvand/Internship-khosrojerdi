<?php
return[
    'username'=>env('SMS_USERNAME',''),
    'password'=>env('SMS_PASSWORD',''),
    'from'=>env('SMS_FROM','')

];