<?php

namespace App\Models\Market;

use App\Models\User\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Order extends Model
{
    use HasFactory, SoftDeletes;

    protected $guarded = ['id'];
    
    protected $cascadeDeletes = ['orderItems'];

    public function orderItems()
    {
        return $this->hasMany(OrderItem::class);
    }

    public function copan()
    {
        return $this->belongsTo(Copan::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
