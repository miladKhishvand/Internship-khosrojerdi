<?php

namespace App\Http\Requests\Admin\Content;

use Illuminate\Foundation\Http\FormRequest;

class storeBlogRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'title' => 'required|max:255|min:5|regex:/^[ا-یa-zA-Z0-9\-?؟۰-۹ء-ي., ]+$/u',
            'image' => 'required|image|mimes:png,jpg,jpeg,webp',
            'body' => 'required|string'
        ];
    }
}
