<?php

namespace App\Http\Controllers\Admin\Content;

use App\Http\Controllers\Controller;
use App\Models\Content\Comment;
use App\Models\Market\Product;
use Illuminate\Http\Request;

class CommentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //change useen status to seen for new comments before returning the view
        $unseenComments = Comment::where('status', 0)->get();
        // hint : status = 0 : unseen  /  status = 1 : seen  / status = 2 : approved / status = 3 : rejected
        foreach ($unseenComments as $unseenComment) {
            $unseenComment->status = 1;
            $unseenComment->save();
        }

        $comments = Comment::orderByDesc('created_at')->paginate(10);
        return view('admin.content.comment.index', compact('comments'));
    }


    public function changeStatus(Comment $comment)
    {
        if ($comment->status == 1 or $comment->status == 3) {
            // approving a comment for first time or re-approving a rejected comment
            $comment->update(['status' => 2]);

            // change comment's parent status to apprved. and also update product's rate
            if ($comment->parent != null and $comment->parent->status != 2) {
                // check the same thing for parent's parent
                // **hint: comment can have a grand parent in our scenario
                if ($comment->parent->parent != null and $comment->parent->parent->status != 2) {
                    $grandParent = $comment->parent->parent;
                    $grandParent->update(['status' => 2]);
                    $this->updateProductRate($comment->parent->parent->commentable);
                }
                $comment->parent()->update(['status' => 2]);
                $this->updateProductRate($comment->parent->commentable);
            }
            
            if ($comment->parent_id == null and $comment->commentable_type == Product::class) {
                $this->updateProductRate($comment->commentable);
            }
            return back()->with('swal-success', 'نظر تایید شد');

        } elseif ($comment->status == 2) {
            $comment->update(['status' => 3]);
            // when comment's status changes to seen, it's answers should do the same
            
            foreach ($comment->answers as $answer) {
                $answer->update(['status' => 3]);
                // status for second answers will be changed like first answers to seen
                foreach ($answer->answers as $secondAnswer) {
                    $secondAnswer->update(['status' => 3]);
                }
            }
            return back()->with('swal-success', 'نظر و پاسخ های آن رد تایید شدند!');
        }
        
    }
    
    /**
     * Display the specified resource.
     */
    public function show(Comment $comment)
    {
        return view('admin.content.comment.show', compact('comment'));
    }

    public function updateProductRate(Product $product)
    {
        $comments = $product->comments()->where('status', 2)->whereNot('rate', 0)->whereNull('parent_id')->get();
        if ($comments->count() > 0) {
            $rate = round($comments->sum('rate') / $comments->count(), 1);
            $product->update(['rate' => $rate]);
        }

    }
}
